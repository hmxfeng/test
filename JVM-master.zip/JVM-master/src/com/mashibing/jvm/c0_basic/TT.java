package com.mashibing.jvm.c0_basic;

public class TT {
    int m = 8;

    public static void main(String[] args) {
        TT t = new TT();
    }
}
