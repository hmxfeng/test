package com.mashibing.jvm.c1_bytecode;

public class T0100_ByteCode01 {
}
