package com.mashibing.jvm.c1_bytecode;

import java.io.Serializable;

public class T0101_ByteCode_With_Interfaces implements Cloneable, Serializable {
}
